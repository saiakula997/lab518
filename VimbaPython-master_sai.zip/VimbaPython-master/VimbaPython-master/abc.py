from vimba import *
import cv2

with Vimba.get_instance() as vimba:
    camera_list = vimba.get_all_cameras()

    if len(camera_list) == 0:
        print("No cameras found!")
        exit()

    selected_camera = camera_list[0]
    selected_camera._open()

    # Configure camera settings (optional)
    selected_camera.ExposureTime = 5000  # Set exposure time to 5 milliseconds
    selected_camera.Gain = 1.0  # Set gain to 1.0

    #selected_camera.start_capture()
    frame = selected_camera.get_frame()

    # Access the raw image data from the frame
    image_data = frame.buffer_data()

    # Convert the image data to a format compatible with OpenCV
    image_array = numpy.array(image_data, dtype=numpy.uint8)

    # Reshape the image array based on the frame dimensions
    image_array = image_array.reshape((frame.height, frame.width))

    # Save the captured image using OpenCV
    cv2.imwrite("captured_image.jpg", image_array)

    selected_camera.stop_capture()
    selected_camera.close()

    vimba.shutdown()
